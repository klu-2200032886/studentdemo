
package com.example.demo1;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class DataInitializer {
    @Bean
    CommandLineRunner loadData(CustomerRepository repository) {
        return args -> {
            repository.save(new Customer(null, "Alice", "alice@example.com", "1234567890", "Street 1", LocalDate.of(1990, 1, 1)));
            repository.save(new Customer(null, "Bob", "bob@example.com", "9876543210", "Street 2", LocalDate.of(1985, 5, 15)));
        };
    }
}
